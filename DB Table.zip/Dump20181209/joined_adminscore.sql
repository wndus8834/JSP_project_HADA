-- MySQL dump 10.13  Distrib 5.7.22, for Win64 (x86_64)
--
-- Host: 54.180.90.56    Database: joined
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.34-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adminscore`
--

DROP TABLE IF EXISTS `adminscore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminscore` (
  `userDepart` varchar(50) NOT NULL,
  `userProcess` varchar(45) NOT NULL,
  `userAdmission` varchar(45) NOT NULL,
  `totalCulture` int(11) DEFAULT NULL,
  `totalCultureNecessary` int(11) DEFAULT NULL,
  `totalMajor` int(11) DEFAULT NULL,
  `totalMajorNecessary` int(11) DEFAULT NULL,
  `totalGraduate` int(11) DEFAULT NULL,
  `totalAbility` int(11) DEFAULT NULL,
  `totalFindMajor` int(11) DEFAULT NULL,
  PRIMARY KEY (`userDepart`,`userProcess`,`userAdmission`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminscore`
--

LOCK TABLES `adminscore` WRITE;
/*!40000 ALTER TABLE `adminscore` DISABLE KEYS */;
INSERT INTO `adminscore` VALUES ('컴퓨터공학과','복수전공','2013',32,16,60,40,130,0,0),('컴퓨터공학과','복수전공','2018',34,16,30,2,130,18,18),('컴퓨터공학과','주전공','2013',32,6,80,64,130,0,0),('컴퓨터공학과','편입','2013',2,2,2,2,2,0,0),('타과','복수전공','2013',35,32,40,1,130,0,0),('타과','부전공','2013',32,4,5,0,130,0,0);
/*!40000 ALTER TABLE `adminscore` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-09 20:03:16
