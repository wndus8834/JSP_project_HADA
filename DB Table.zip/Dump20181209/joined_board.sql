-- MySQL dump 10.13  Distrib 5.7.22, for Win64 (x86_64)
--
-- Host: 54.180.90.56    Database: joined
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.34-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `board` (
  `userID` varchar(20) DEFAULT NULL,
  `boardID` int(11) NOT NULL,
  `boardTitle` varchar(50) DEFAULT NULL,
  `boardContent` varchar(2048) DEFAULT NULL,
  `boardDate` datetime DEFAULT NULL,
  `boardHit` int(11) DEFAULT NULL,
  `boardFile` varchar(100) DEFAULT NULL,
  `boardRealFile` varchar(100) DEFAULT NULL,
  `boardGroup` int(11) DEFAULT NULL,
  `boardSequence` int(11) DEFAULT NULL,
  `boardLevel` int(11) DEFAULT NULL,
  `boardAvailable` int(11) DEFAULT NULL,
  PRIMARY KEY (`boardID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES ('201331022',2,'수정1','수정1','2018-12-01 00:12:47',16,'comNtest.csv','comNtest5.csv',1,0,0,1),('201331022',4,'ㅅㄷㄴㅅ','ㅅㅅ','2018-12-03 02:04:17',0,'comNtest.csv','comNtest.csv',2,0,0,1),('201331022',5,'답변1','ㅇㅇ','2018-12-03 02:04:52',2,'','',1,1,1,0),('201331022',6,'ee','ee','2018-12-03 02:15:44',0,'','',1,2,2,1),('201331022',7,'1','1','2018-12-03 03:40:10',0,'','',3,0,0,1),('201331022',8,'2','2','2018-12-03 03:40:19',0,'','',4,0,0,1),('201331022',9,'3','3','2018-12-03 03:40:31',0,'','',5,0,0,1),('201331022',10,'4','4','2018-12-03 03:40:42',0,'','',6,0,0,1),('201331022',11,'5','5','2018-12-03 03:40:51',0,'','',7,0,0,1),('201331022',12,'7','7','2018-12-03 03:41:06',0,'','',8,0,0,1),('201331022',13,'8','8','2018-12-03 03:43:16',0,'','',9,0,0,1),('201331022',14,'9','9','2018-12-03 03:46:43',1,'','',10,0,0,1),('201331022',15,'10','1','2018-12-03 03:47:12',0,'','',11,0,0,1),('201331022',16,'a','a','2018-12-03 04:21:11',0,'','',12,0,0,1),('201331022',17,'b','b','2018-12-03 04:21:20',0,'','',13,0,0,1),('201331022',18,'c','c','2018-12-03 04:21:43',0,'','',14,0,0,1),('201331022',19,'d','d','2018-12-03 04:21:53',0,'','',15,0,0,1),('201331022',20,'1','1','2018-12-03 04:22:04',0,'','',16,0,0,1),('201331022',21,'1','1','2018-12-03 04:22:09',0,'','',17,0,0,1),('201331022',22,'1','1','2018-12-03 04:22:13',0,'','',18,0,0,1),('201331022',23,'1','1','2018-12-03 04:22:17',0,'','',19,0,0,1),('201331022',24,'1','1','2018-12-03 04:22:20',0,'','',20,0,0,1),('201331022',25,'1','1','2018-12-03 04:22:23',0,'','',21,0,0,1),('201331022',26,'1','1','2018-12-03 04:22:27',0,'','',22,0,0,1),('201331022',27,'1','1','2018-12-03 04:22:52',0,'','',23,0,0,1),('201331022',28,'1','1','2018-12-03 04:22:55',1,'','',24,0,0,1),('201331022',29,'1','1','2018-12-03 04:22:58',0,'','',25,0,0,1),('201331022',30,'1','1','2018-12-03 04:23:02',0,'','',26,0,0,1),('201331022',31,'1','1','2018-12-03 04:23:06',0,'','',27,0,0,1),('201331022',32,'1','1','2018-12-03 04:23:08',0,'','',28,0,0,1),('201331022',33,'1','1','2018-12-03 04:23:13',0,'','',29,0,0,1),('201331022',34,'1','1','2018-12-03 04:23:17',0,'','',30,0,0,1),('201331022',35,'1','1','2018-12-03 04:23:20',0,'','',31,0,0,1),('201331022',36,'1','1','2018-12-03 04:23:24',0,'','',32,0,0,1),('201331022',37,'1sdasd','1adad','2018-12-03 04:23:31',0,'','',33,0,0,1),('201331022',38,'1sdasd','1adad','2018-12-03 04:23:35',0,'','',34,0,0,1),('201331022',39,'1sdasd','1adad','2018-12-03 04:23:39',0,'','',35,0,0,1),('201331022',40,'1sdasd','1adad','2018-12-03 04:23:43',0,'','',36,0,0,1),('201331022',41,'1sdasd','1adad','2018-12-03 04:23:47',0,'','',37,0,0,1),('201331022',42,'1sdasdzzz','1adadzz','2018-12-03 04:23:53',1,'','',38,0,0,1),('201331022',43,'1sdasdzzz','1adadzz','2018-12-03 04:23:58',2,'','',39,0,0,1),('201331022',44,'1sdasdzzz','1adadzz','2018-12-03 04:24:01',76,'','',40,0,0,1);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-09 20:03:20
